package com.springserver.BanThing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BanThingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BanThingApplication.class, args);
	}

}
